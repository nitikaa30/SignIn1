package com.example.signin

data class Data(
    val Email: String,
    val Id: Int,
    val Name: String,
    val Token: String
)