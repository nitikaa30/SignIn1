package com.example.signin

data class LogIn(
    val email: String,
    val password: Int
)