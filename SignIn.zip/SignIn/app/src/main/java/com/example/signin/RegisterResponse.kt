package com.example.signin

data class RegisterResponse(
    val code: Int,
    val `data`: Data?,
    val message: String
)